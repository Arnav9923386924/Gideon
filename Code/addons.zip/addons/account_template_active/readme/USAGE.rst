* Go to Accounting > Configuration > Templates
* Select then the template you want to change.
