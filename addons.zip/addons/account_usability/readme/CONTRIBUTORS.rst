* Sylvain LE GAL <https://twitter.com/legalsylvain>
* Raf Ven <raf.ven@dynapps.be>
* Alexis de Lattre <alexis.delattre@akretion.com>
* Álvaro Trius <alvaro.trius@forgeflow.com>
