The purchase order line will be automatically copied to the journal items.

* When a supplier invoice is created referencing purchase orders, the
  purchase order line will be copied to the corresponding journal item.

* When a stock move is validated and generates a journal entry, the purchase
  order line is copied to the account move line.
