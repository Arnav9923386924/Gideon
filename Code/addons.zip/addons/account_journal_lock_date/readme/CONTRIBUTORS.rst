* `Akretion <https://www.akretion.com>`_:

  * Benoît GUILLOT <benoit.guillot@akretion.com>
  * Chafique DELLI <chafique.delli@akretion.com>
  * Alexis de Lattre <alexis.delattre@akretion.com>
  * Mourad EL HADJ MIMOUNE <mourad.elhadj.mimoune@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Ernesto Tejeda

* `Factor Libre <https://www.factorlibre.com>`_:

  * Rodrigo Bonilla Martinez <rodrigo.bonilla@factorlibre.com>
