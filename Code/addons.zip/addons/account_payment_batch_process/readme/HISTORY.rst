12.0.1.1.0
~~~~~~~~~~

**Features**

- Remove menu "Batch Payments" from Vendors and Customers
- Remove menu "Register Payment" from batch invoices.

12.0.1.0.0
~~~~~~~~~~

- Initial File
