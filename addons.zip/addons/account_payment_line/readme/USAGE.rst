You can use payment distribution suggestion, and if system found moves
pending to reconcile related with partner selected, system will create
all lines trying to pay all invoices until amount remain

You can add manually lines, if payment don't detect lines specified, payment
works as a normal payment
