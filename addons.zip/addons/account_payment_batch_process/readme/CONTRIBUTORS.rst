* Balaji Kannan <bkannan@opensourceintegrators.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* Mayank Gosai <mgosai@opensourceintegrators.com>
* Sandip Mangukiya <smangukiya@opensourceintegrators.com>
* Hardik Suthar <hsuthar@opensourceintegrators.com>

* Camptocamp <https://www.camptocamp.com>
  * Denis Leemann <denis.leemann@camptocamp.com>
