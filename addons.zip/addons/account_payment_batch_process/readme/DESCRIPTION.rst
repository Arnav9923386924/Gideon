Batch Payments Processing for Customers Invoices and Supplier Invoices/Vendor Bills.

Payments to multiple vendors can be processed. Payments from multiple customers can be processed.

Partial payments can be processed leaving invoice/bill open or writing off unpaid portion to a write-off account.
