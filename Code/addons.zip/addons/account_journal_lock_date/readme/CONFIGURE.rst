To configure this module, you need to:

#. Go to *Invoicing > Configuration > Journals*
#. Open a Journal and set the 'Lock Date' and the 'Lock Date for Non-Advisers'
   in the' Advanced Settings' tab of the form view or select several
   Journals in the list view and click on the action menu
   'Update journals lock dates' to update those dates for the selected
   journals at the same time.
