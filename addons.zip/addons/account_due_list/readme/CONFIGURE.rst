To use this module, you need to:

#. Activate developer mode.
#. Go to *Settings > Users & Companies > Groups*.
#. Search for and choose "Technical / Show Full Accounting Features".
#. Edit it, and add your user on the "Users" tab
