This module will add the sale order line to journal items.

The ultimate goal is to establish the purchase order line as one of the key
fields to reconcile the Goods Delivered Not Invoiced accrual account.
