This module allows to have three successive discounts on each invoice line.
