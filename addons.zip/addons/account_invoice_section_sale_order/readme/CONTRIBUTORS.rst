* `Camptocamp <https://www.camptocamp.com>`_

  * Thierry Ducrest <thierry.ducrest@camptocamp.com>
  * Akim Juillerat <akim.juillerat@camptocamp.com>
  * Hiep Nguyen Hoang <hiepnh@trobz.com>

* `Dynapps <https://www.dynapps.eu>`_

  * Jeroen Evens
  * Raf Ven
