* David Vidal <david.vidal@tecnativa.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* `Aion Tech <https://aiontech.company/>`_:

  * Simone Rubino <simone.rubino@aion-tech.it>

* Laurent Mignon <laurent.mignon@acsone.eu>
* Akim Juillerat <akim.juillerat@camptocamp.com>
