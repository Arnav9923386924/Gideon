This is a technical module that adds the next views (since Odoo 16.0, these views are not part of the *account* module any more):
  - **Bank Statement**
  - **Bank Statement Lines**


