* 7 i TRIA <http://www.7itria.cat>
* Avanzosc <http://www.avanzosc.com>
* Markus Schneider <markus.schneider@initos.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Sergio Teruel
  * Carlos Dauden
  * David Vidal
  * Luis M. Ontalba
  * Ernesto Tejeda
  * João Marques
