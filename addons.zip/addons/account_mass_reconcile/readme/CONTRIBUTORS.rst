* Sébastien Beau <sebastien.beau@akretion.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Vincent Renaville <vincent.renaville@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Joël Grand-Guillaume <joel.grandguillaume@camptocamp.com>
* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Pedro M.Baeza <pedro.baeza@gmail.com>
* Matthieu Dietrich <matthieu.dietrich@camptocamp.com>
* Leonardo Pistone <leonardo.pistone@camptocamp.com>
* Ecino <ecino@compassion.ch>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Rudolf Schnapka <rs@techno-flex.de>
* Florian Dacosta <florian.dacosta@akretion.com>
* Laetitia Gangloff <laetitia.gangloff@acsone.eu>
* Frédéric Clémenti <frederic.clementi@camptocamp.com>
* Damien Crier <damien.crier@camptocamp.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Mykhailo Panarin <m.panarin@mobilunity.com>
* Adrià Gil Sorribes <adria.gil@forgeflow.com>
* `Trobz <https://trobz.com>`_:

    * Son Ho <sonhd@trobz.com>
