The sale order line will be automatically copied to the journal items.

* When a supplier invoice is created referencing sales orders, the
  sale order line will be copied to the corresponding journal item.

* When a stock move is validated and generates a journal entry, the sale
  order line is copied to the account move line.
