If the logged-in user has the access group 'Adviser', he/she will
not be able to create a journal entry if the 'Lock Date' of the
journal is greater than or equal to the journal entry.

If the logged-in user has not the access group 'Adviser', he/she will
not be able to create a journal entry if the 'Lock Date for Non-Advisers'
of the journal is greater than or equal to the journal entry.
